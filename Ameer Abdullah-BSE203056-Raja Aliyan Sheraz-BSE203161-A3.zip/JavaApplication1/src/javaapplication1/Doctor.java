/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author Sparta Laptop
 */
public class Doctor {
 public Doctor() {
         fullname= null;
        fathername=null;
         email=null;
         contactno=null;
         address=null;
         qualification=null;
         gender=null;
         bloodGroup=null;
    }
    public Doctor(String fullname, String fathername, String email, String contactno, String address, String qualification, String gender, String bloodGroup) {
        this.fullname = fullname;
        this.fathername = fathername;
        this.email = email;
        this.contactno = contactno;
        this.address = address;
        this.qualification = qualification;
        this.gender = gender;
        this.bloodGroup = bloodGroup;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }
    private String fullname;
    private String fathername;
    private String email;
    private String contactno;
    private String address;
    private String qualification;
    private String gender;
    private String bloodGroup;
    
}
