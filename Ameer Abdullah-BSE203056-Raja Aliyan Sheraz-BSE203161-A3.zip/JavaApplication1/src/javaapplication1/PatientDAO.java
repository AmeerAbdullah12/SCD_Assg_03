/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sparta Laptop
 */
public class PatientDAO {
     Connection c;
    Statement st;
    ResultSet rs;
    
    public PatientDAO() throws SQLException
    {
         try {
            //driverIP Address
            Class.forName("com.mysql.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
            st = c.createStatement();
            System.out.println("Database connected");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DoctorDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Database  not connected");
        }
    }
    public void PatientCreation(Patient D){
       String q = " INSERT INTO patient Values (?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps;
        try {
            ps = c.prepareStatement(q);
             ps.setString(1, D.getId());
             ps.setString(2, D.getName());
             ps.setString(3, D.getFatherName());
             ps.setString(4, D.getEmail());
             ps.setString(5, D.getContactNumber());
             ps.setString(6, D.getAddress()); 
             ps.setString(7, D.getInformation());  
             ps.setString(8, D.getGender());  
             ps.setString(9, D.getBloodGroup());  
             ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void PatientDeletion(String id){
        String q = " delete from patient where id=?";
        PreparedStatement ps;
        try {
            ps = c.prepareStatement(q);
        
             ps.setString(1, id);
             ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void PatientUpdation(Patient D){
         String q = " INSERT INTO patient Values (?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps;
        try {
            ps = c.prepareStatement(q);
             ps.setString(1, D.getId());
             ps.setString(2, D.getName());
             ps.setString(3, D.getFatherName());
             ps.setString(4, D.getEmail());
             ps.setString(5, D.getContactNumber());
             ps.setString(6, D.getAddress()); 
             ps.setString(7, D.getInformation());  
             ps.setString(8, D.getGender());  
             ps.setString(9, D.getBloodGroup());  
             ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void PatientView(String id){
        String q = " select* from patient where id=?";
        PreparedStatement ps;
        try {
            ps = c.prepareStatement(q);
        
             ps.setString(1, id);
             rs=ps.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
