/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author Sparta Laptop
 */
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;

/**
 *
 * @author Sharjeel Shahzad
 */
public class DoctorDetailsForm extends JFrame {
    private JTextField idField, fullNameField, fatherNameField, emailField, contactNoField, addressField;
    private JComboBox<String> qualificationDropdown, genderDropdown, bloodGroupDropdown;
    private JSpinner dateOfBirthSpinner;
    private JButton saveButton, updateButton, newButton, getDataButton;

    public DoctorDetailsForm() {
        // Set the window title
        setTitle("Doctor Details Form");

        // Create labels
        JLabel idLabel = new JLabel("Doctor's ID:");
        JLabel fullNameLabel = new JLabel("Full Name:");
        JLabel fatherNameLabel = new JLabel("Father's Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel contactNoLabel = new JLabel("Contact No.:");
        JLabel addressLabel = new JLabel("Address:");
        JLabel qualificationLabel = new JLabel("Qualification:");
        JLabel genderLabel = new JLabel("Gender:");
        JLabel bloodGroupLabel = new JLabel("Blood Group:");
        JLabel dateOfBirthLabel = new JLabel("Date of Joining:");

        // Create text fields
        idField = new JTextField(20);
        fullNameField = new JTextField(20);
        fatherNameField = new JTextField(20);
        emailField = new JTextField(20);
        contactNoField = new JTextField(20);
        addressField = new JTextField(20);

        // Create qualification dropdown
        String[] qualifications = {"MBBS", "MD", "MS"};
        qualificationDropdown = new JComboBox<>(qualifications);

        // Create gender dropdown
        String[] genders = {"Male", "Female", "Other"};
        genderDropdown = new JComboBox<>(genders);

        // Create blood group dropdown
        String[] bloodGroups = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
        bloodGroupDropdown = new JComboBox<>(bloodGroups);

        // Create date of joining spinner
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dateOfBirthSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateOfBirthSpinner, "yyyy-MM-dd");
        dateOfBirthSpinner.setEditor(dateEditor);

        // Create buttons
        saveButton = new JButton("Save");
        updateButton = new JButton("Update");
        newButton = new JButton("delete");
        getDataButton = new JButton("Get Data");

        // Create a panel to hold the components
        JPanel panel = new JPanel(new GridLayout(12, 2));
        panel.add(idLabel);
        panel.add(idField);
        panel.add(fullNameLabel);
        panel.add(fullNameField);
        panel.add(fatherNameLabel);
        panel.add(fatherNameField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(contactNoLabel);
        panel.add(contactNoField);
        panel.add(addressLabel);
        panel.add(addressField);
        panel.add(qualificationLabel);
        panel.add(qualificationDropdown);
        panel.add(genderLabel);
        panel.add(genderDropdown);
        panel.add(bloodGroupLabel);
        panel.add(bloodGroupDropdown);
        panel.add(dateOfBirthLabel);
        panel.add(dateOfBirthSpinner);
        panel.add(saveButton);
        panel.add(updateButton);
        panel.add(newButton);
        panel.add(getDataButton);

        // Add the panel to the content pane
        getContentPane().add(panel);

        // Set the default close operation and display the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
         setLocationRelativeTo(null); // Center the frame on the screen
        setVisible(true);
        saveButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            setVisible(false);
            DoctorController obj1= new DoctorController();
            String a= (String)qualificationDropdown.getSelectedItem();
            String b=(String)genderDropdown.getSelectedItem();
            String c=(String)bloodGroupDropdown.getSelectedItem();
            Doctor obj2= new Doctor(fullNameField.getText(), fatherNameField.getText(), emailField.getText(), contactNoField.getText(), addressField.getText(),a,b,c);
            System.out.println(fullNameField.getText());
            obj1.createDoctor(obj2);
        }
       
    });
         updateButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                 DoctorController obj1= new DoctorController();
                 String a= (String)qualificationDropdown.getSelectedItem();
            String b=(String)genderDropdown.getSelectedItem();
            String c=(String)bloodGroupDropdown.getSelectedItem();
            Doctor obj2= new Doctor(fullNameField.getText(), fatherNameField.getText(), emailField.getText(), contactNoField.getText(), addressField.getText(),a,b,c);
            obj1.updateDoctor(obj2);
            }
            
        });
        
         newButton.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
                DoctorController obj1= new DoctorController();
                obj1.deleteDoctor(idField.getText());
            }
             
         });
    }
}

