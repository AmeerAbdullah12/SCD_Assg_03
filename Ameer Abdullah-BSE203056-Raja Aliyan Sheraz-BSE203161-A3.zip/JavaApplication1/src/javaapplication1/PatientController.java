/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.sql.SQLException;

/**
 *
 * @author Sparta Laptop
 */
public class PatientController {
    public void CreatePatient(Patient obj) throws SQLException{
        PatientDAO obj1= new PatientDAO();
        obj1.PatientCreation(obj);
    }
    public void UpdatePatient(Patient obj) throws SQLException{
         PatientDAO obj1= new PatientDAO();
        obj1.PatientUpdation(obj);
    }
    public void DeletePatient(String id) throws SQLException{
         PatientDAO obj1= new PatientDAO();
        obj1.PatientDeletion(id);
    }
    public void ViewPatient(String id) throws SQLException{
         PatientDAO obj1= new PatientDAO();
        obj1.PatientView(id);
    }
}
