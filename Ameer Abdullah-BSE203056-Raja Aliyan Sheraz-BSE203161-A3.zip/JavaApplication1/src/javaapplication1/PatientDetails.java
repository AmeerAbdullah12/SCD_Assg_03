/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author Sparta Laptop
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class PatientDetails {
    public Services runServiceForm;
    PatientDetails() {
        JFrame frame = new JFrame("Patient Information");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.PAGE_AXIS));
        JButton update=new JButton("Update");
         JButton Delete=new JButton("Delete");
        JButton clear=new JButton("Clear");
        JButton service=new JButton("Proceed to services");
        
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(20);

        JLabel idLabel = new JLabel("ID:");
        JTextField idField = new JTextField(10);

        JLabel ageLabel = new JLabel("Age:");
        JTextField ageField = new JTextField(10);

        JLabel fatherNameLabel = new JLabel("Father's Name:");
        JTextField fatherNameField = new JTextField(20);

        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField(20);

        JLabel contactNumberLabel = new JLabel("Contact Number:");
        JTextField contactNumberField = new JTextField(15);

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(20);

        JLabel bloodGroupLabel = new JLabel("Blood Group:");
        JTextField bloodGroupField = new JTextField(5);

        JLabel genderLabel = new JLabel("Gender:");
        String[] genders = {"Male", "Female"};
        JComboBox<String> genderComboBox = new JComboBox<>(genders);

        JLabel informationLabel = new JLabel("Additional Information:");
        JTextField informationArea = new JTextField(50);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
          
             PatientController obj1= new PatientController();
            String name = nameField.getText();
            String id = idField.getText();
            String age = ageField.getText();
            String fatherName = fatherNameField.getText();
            String address = addressField.getText();
            String contactNumber = contactNumberField.getText();
            String email = emailField.getText();
            String bloodGroup = bloodGroupField.getText();
            String gender = (String) genderComboBox.getSelectedItem();
            String information = informationArea.getText();
            Patient obj2= new Patient(name,age,fatherName,address,contactNumber,email,bloodGroup,gender,information);
             obj1.CreatePatient(obj2);
            // Display the collected patient information
            JOptionPane.showMessageDialog(frame,
                    "Name: " + name + "\n" +
                    "ID: " + id + "\n" +
                    "Age: " + age + "\n" +
                    "Father's Name: " + fatherName + "\n" +
                    "Address: " + address + "\n" +
                    "Contact Number: " + contactNumber + "\n" +
                    "Email: " + email + "\n" +
                    "Blood Group: " + bloodGroup + "\n" +
                    "Gender: " + gender + "\n" +
                    "Additional Information: " + information);
            
        });
        clear.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            nameField.setText(null);
            idField.setText(null);
            ageField.setText(null);
            contactNumberField.setText(null);
            addressField.setText(null);
            fatherNameField.setText(null);
            emailField.setText(null);
            bloodGroupField.setText(null);
            informationArea.setText(null);
        }
    });
        
        service.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
        runServiceForm=new Services();
        }
        });
        frame.setLayout(new GridLayout(15,2));
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(idLabel);
        frame.add(idField);
        frame.add(ageLabel);
        frame.add(ageField);
        frame.add(fatherNameLabel);
        frame.add(fatherNameField);
        frame.add(addressLabel);
        frame.add(addressField);
        frame.add(contactNumberLabel);
        frame.add(contactNumberField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(bloodGroupLabel);
        frame.add(bloodGroupField);
        frame.add(genderLabel);
        frame.add(genderComboBox);
        frame.add(informationLabel);
        frame.add(informationArea);
        frame.add(submitButton);
        frame.add(update);
        frame.add(Delete);
        frame.add(clear);
        frame.setVisible(true);
    }
}

