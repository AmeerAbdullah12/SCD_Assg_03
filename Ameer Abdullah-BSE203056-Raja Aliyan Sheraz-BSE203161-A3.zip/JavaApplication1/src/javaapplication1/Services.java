/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author Sparta Laptop
 */
import javax.swing.*;
import java.awt.*;
public class Services extends JFrame{
    
    public JTextField s_name, s_date, s_charges,t4,t5;
    public JLabel l1,l2,l3,l4,l5;
    public JButton save=new JButton("Save");
    public Services(){
        l1=new JLabel("Service name ");
        l2=new JLabel("Service date ");
        l3=new JLabel("Service Charges ");
        l4=new JLabel("Patient ID ");
        l5=new JLabel("Patient name ");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6,2));
        add(l1);
        add(s_name);
        add(l2);
        add(s_date);
        add(l3);
        add(s_charges);
        add(l4);
        add(t4);
        add(l5);
        add(t5);
        add(save);
        setVisible(true);
    }

    
}

