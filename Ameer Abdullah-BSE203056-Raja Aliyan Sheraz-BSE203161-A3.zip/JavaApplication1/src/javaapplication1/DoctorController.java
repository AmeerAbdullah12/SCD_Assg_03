/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.sql.SQLException;

/**
 *
 * @author Sparta Laptop
 */
public class DoctorController {
    DoctorDAO obj2;

    public DoctorController() throws SQLException {
        this.obj2 = new DoctorDAO();
    }
    public void createDoctor(Doctor obj1){
        obj2.DoctorCreation(obj1);
        
    }
    public void updateDoctor(Doctor obj){
         obj2.DoctorCreation(obj);
    }
    public void deleteDoctor(String id){
        obj2.DoctorDeletion(id);
    }
    public void viewDoctor(String id){
    obj2.DoctorView(id);
    }
}
